/**
 * En este paquete se guardan las clases:.
 * -ArbitroAbstracto.
 * -ArbitroSeguro.
 * -ArbitroInseguro.
 * -La interfaz Arbitro.
 * @since 1.0
 */
package juego.control;