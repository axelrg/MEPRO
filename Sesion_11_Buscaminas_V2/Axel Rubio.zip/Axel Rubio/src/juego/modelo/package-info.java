/**
 * En este paquete se guardan las clases Celda, Estado y Tablero.
 *
 * @since 1.0
 */
package juego.modelo;