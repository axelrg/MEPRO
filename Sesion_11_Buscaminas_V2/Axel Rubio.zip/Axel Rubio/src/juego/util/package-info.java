/**
 * En este paquete se guardan CoordenadasIncorrectasException y sentido.
 * <p>
 *
 * @since 1.0
 */
package juego.util;