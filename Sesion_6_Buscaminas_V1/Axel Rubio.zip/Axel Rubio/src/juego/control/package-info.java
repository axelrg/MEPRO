/**
 * En este paquete se guardan las clases Arbitro y DistaciaChebyshev.
 *
 * @since 1.0
 */
package juego.control;